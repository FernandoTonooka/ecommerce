
package business;

import domain.EntidadeDominio;

public interface IStrategy {
    
    	public String processar(EntidadeDominio entidade);
    
}
